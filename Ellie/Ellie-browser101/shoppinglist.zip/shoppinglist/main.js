'use strict' ;

const items = document.querySelector('.items');
const inputText = document.querySelector('.addText');
const inputNum = document.querySelector('.addNum');
const addBtn = document.querySelector('.addBtn');


function onAdd() {
    // 1. 사용자가 입력한 텍스트를 받아옴
    const text = inputText.value;
    console.log(text);
    // // 2. 새로운 아이템을 만듦 (텍스트 + 삭제 버튼)
    const item = createItem();
    
    // // 3. items 컨테이너안에 새로 만든 아이템을 추가한다. 
    items.appendChild(item);

    // 4. input 을 초기화한다. 
    inputText.value = '';
    inputText.focus();
}

function createItem(text) {
    const itemRow = document.createElement('li');
    itemRow.setAttribute('class', 'item__row');

    const item = document.createElement('div');
    item.setAttribute('class', 'item');
    
    const itemName = document.createElement('div');
    itemName.setAttribute('class', 'item__name');
    itemName.innerText = text;
    
    const icons = document.createElement('div');
    icons.setAttribute('class', 'icons');
    
    const checkBtn = document.createElement('button');
    checkBtn.setAttribute('class', 'iconcircle check');
    checkBtn.innerHTML = '<i class="fas fa-check"></i>';

    const deleteBtn = document.createElement('button');
    deleteBtn.setAttribute('class', 'iconcircle bin');
    deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
    deleteBtn.addEventListener('clcik', () => {
        items.removeChild(itemRow);
    });

    icons.appendChild(checkBtn);
    icons.appendChild(deleteBtn);

    item.appendChild(itemName);
    item.appendChild(icons);

    itemRow.appendChild(item);

    items.appendChild(itemRow);

    return itemRow;
}

addBtn.addEventListener('click', () => {
    onAdd();
});

{/* <ul class="items">
<li class="item__row">
    <div class="item">
        <div class="item__name">Bread | 1ea</div> 
        <div class="icons">
            <button class="iconcircle check"><i class="fas fa-check"></i></button>
            <button class="iconcircle bin"><i class="fas fa-trash"></i></button>
        </div>
    </div>

</li>
</ul>  */}

